#include <iostream>
#include <string.h>
#include <iomanip>
using namespace std;

struct itementry

  {
    double unit_price;
    int copies, product_id;
    char name[30];
    char company [30];
   };

  class store {

  public:

    int numitem;
    itementry database[100];

    store()
    {
      numitem = 0;
    }

    void insertitem (char itemname[], char company[], int pid, int c, double p);
    itementry *searchi (char itemname[], int pid);
    void updateitem (char itemname[], int pid, int total, double price);
   };

  void store::insertitem (char itemname[], char company[], int pid, int c, double p)
   {

     strcpy (database [numitem]. name, itemname);
     strcpy (database [numitem]. company, company);
     database [numitem]. product_id = pid;
     database [numitem]. copies = c;
     database [numitem]. unit_price = p;
     cout << "\n\t\t Item Inserted Successfully \n" << endl;
     numitem++;

   }

  itementry *store::searchi (char itemname [], int pid)
  {
    int i;
    for (i = 0; i < numitem; i++)
    {
      if ((strcmp (itemname, database[i]. name) == 0) && (database [i]. product_id == pid))
      return &database[i];
    }
    return NULL;
  }

 void store::updateitem (char itemname[], int pid, int total, double price)
 {
   itementry *item = searchi (itemname, pid);
   if (item == NULL)
   {
     cout << "\n\t\t\t Item Not Found! \n" << endl;
     return;
   }
   item->copies = total;
   item->unit_price = price;
 }


 

int main() {

  store sto;
  char name [30], company[30];
  int product_id,copies, choice;
  double unit_price;

  cout << fixed << showpoint << setprecision(2);

  do
  {
    cout << "\n\t -Digitory Menu- \n" <<endl;
    cout << "  " << endl;
    cout << "Press 1 To Insert." << endl;
    cout << "Press 2 To Update." << endl;
    cout << "Press 3 To Search." << endl;
    cout << "Press 4 To Exit." << endl;
    cout << "Enter Your Choice: ";
    cin >> choice;

    switch (choice)
    {
      case 1 : cin.getline (name, 80);
               cout << "\n\t\t\t Enter Name of The Product: ";
               cin.getline (name, 80);
               cout << "\n\t\t\t Enter The Name of The Company: ";
               cin.getline (company, 80);
               cout << "\n\t\t\t Enter The Product ID: ";
               cin >> product_id;
               cout << "\n\t\t\t Enter The Number of Copies: ";
               cin >> copies;
               cout << "\n\t\t\t Enter The Price Per Item: $";
               cin >> unit_price;
               sto.insertitem (name, company, product_id, copies, unit_price);
               break;
      case 2 : cout << "\n\t\t\t -Enter Details For Update-" << endl;
               cin.getline (name,80);
               cout << "\n\t\t\t Enter Name of The Product: ";
               cin.getline (name,80);
               cout << "\n\t\t\t Enter The Product ID: ";
               cin >> product_id;
               itementry *test1;
               test1 = sto.searchi (name, product_id);
              if (test1 != NULL)
             {
               cout << "\n\t\t\t Enter New Number of Copies For This Product: ";
               cin >> copies;
               cout << "\n\t\t\t Enter The New Price For This Product: $";
               cin >> unit_price;
               sto.updateitem (name, product_id, copies, unit_price);
             }
             else 
             {
               cout << "\n\t\t Item Not Found! Returning to Menu." << endl;
             }
               break;
      case 3 : cin.getline (name, 80);
      cout << "\n\t\t\t Enter Name of The Product: ";
      cin.getline (name, 80);
      cout << "\n\t\t\t Enter The Product ID: ";
      cin >> product_id;
      itementry *test;
      test = sto.searchi (name, product_id);
      if (test != NULL)
      {
        cout << "\n\t -Searching-" << endl;
        cout << "\n\t\t\t -Item Found-" << endl;
        cout <<"\n\t\t\t Name of The Product: " << test->name << endl;
        cout << "\n\t\t\t Name of The Company: " << test->company << endl;
        cout << "\n\t\t\t Product ID: " << test->product_id << endl;
        cout << "\n\t\t\t Number of Copies Avaliable: " << test->copies << endl;
        cout << "\n\t\t\t Price: $" << test->unit_price << endl;

      }
      else
      {
        cout << "\n\t\t Item Not Found! Returning to Menu" << endl;
    
      }
      break;
      
         

    }
  } while (choice != 4);

  return 0;
}

  